# Welcome to the MUFaSAA Dataset!

This dataset assembles 165 robot embodiments and describes them in terms of their design elements. We also share the data collected from Amazon Mechanical Turk on the robots' design metaphors, social expectations, and functional expectations.

The primary files in this dataset are:
- RobotDescriptors.csv - this file contains all the robot embodiments we surveyed and their annotated design elements.
- RobotAverages.csv - this file contains the compiled metaphors, social expectations, and functional expectations from the studies we conducted.
- We provide all robot images in the imgs folder.

We provide the raw responses from our three online studies in these files:
- CleanedMetaphorResponses(Study1).csv - a compilation of the natural language descriptions, metaphors, and justifaction for the robot metaphors used for each robot
- CleanedSocialResponses(Study2).csv - a compilation of the individual responses of social expectations of each robot, as evaluated by the RoSAS scale, for each robot.
- CleanedFunctionalResponses(Study3).csv - a compilation of the individual responess of functional expectations of each robot as evaluated by the EmCorp Scale for each robot. We also collect specific jobs expectations for each robot in the dataset from laypeople. 

We provide the following files to provide metadata information:
- DemographicInformationMapping.csv - a description of the meaning of each key in the demographic survey.
- FeatureExplanation.csv - A description of what each low-level design feature in RobotDescriptors means.
- MetaphorClassifications.csv - A description of how each design metaphor was classified in terms of Anthropomorphic/Mechanical/Zoomorphic.

For an in-depth explanation of each column in these files, try opening the Jupyter Notebok "load_data.ipynb". To do this locally, run the following commands:

First, install Jupyter Lab.
```
pip install jupyterlab
```

Then, start Jupyter Lab. This will open a window in your browser.
```
jupyter lab
```